package com.example.prueba

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
