package com.example.prueba2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
