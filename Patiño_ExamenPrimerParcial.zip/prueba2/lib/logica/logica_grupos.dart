String determinarGrupo(String nombre, String sexo) {
  if ((sexo.toLowerCase() == "mujer" && nombre[0].toUpperCase().compareTo("M") < 0) ||
      (sexo.toLowerCase() == "hombre" && nombre[0].toUpperCase().compareTo("N") > 0)) {
    return "Grupo A";
  }
  return "Grupo B";
}
