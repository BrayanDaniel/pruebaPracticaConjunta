import 'package:flutter/material.dart';
import 'ui/pantalla_login.dart'; // Importar la pantalla de login

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Clasificación de Grupos',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: PantallaLogin(), // Inicia con la pantalla de login
    );
  }
}
