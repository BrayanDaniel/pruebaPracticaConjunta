import 'package:flutter/material.dart';
import 'pantalla_login.dart';
import '../logica/logica_grupos.dart';
import 'pantalla_resultado.dart';

class PantallaInicio extends StatelessWidget {
  final TextEditingController nombreController = TextEditingController();
  final TextEditingController sexoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Elimina la flecha de retroceso
        title: Center(
          child: Text(
            'Clasificación de Grupos',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white, // Cambié el color a blanco
            ),
          ),
        ),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Align(
              alignment: Alignment.topCenter,
              child: ClipOval(
                child: Image.network(
                  'https://st.depositphotos.com/1979759/3199/i/450/depositphotos_31994031-stock-photo-two-different-working-groups-concept.jpg',
                  height: 180,
                  width: 180,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(height: 30),
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                labelStyle: TextStyle(color: Colors.green),
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: sexoController,
              decoration: InputDecoration(
                labelText: 'Sexo (Hombre o Mujer)',
                labelStyle: TextStyle(color: Colors.green),
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            SizedBox(height: 30),
            SizedBox(
              width: 250,
              child: ElevatedButton(
                onPressed: () {
                  String nombre = nombreController.text.trim();
                  String sexo = sexoController.text.trim();

                  if (nombre.isEmpty || RegExp(r'[^a-zA-Z\s]').hasMatch(nombre)) {
                    mostrarError(context, 'Por favor ingresa un nombre válido (solo letras).');
                    return;
                  }

                  if (sexo.isEmpty || (sexo != 'Hombre' && sexo != 'Mujer')) {
                    mostrarError(context, 'Por favor ingresa "Hombre" o "Mujer" en el campo Sexo.');
                    return;
                  }

                  String grupo = determinarGrupo(nombre, sexo);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PantallaResultado(nombre: nombre, sexo: sexo, grupo: grupo),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                ),
                child: Text(
                  'Determinar Grupo',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
            Spacer(), // Empuja el botón de cerrar sesión hacia la parte inferior
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => PantallaLogin()),
                      (Route<dynamic> route) => false, // Elimina todas las rutas previas
                );
              },
              icon: Icon(Icons.logout, color: Colors.white),
              label: Text(
                'Cerrar Sesión',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Colors.white,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, // Cambié el color a rojo para resaltar
                padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void mostrarError(BuildContext context, String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(mensaje),
        backgroundColor: Colors.red,
      ),
    );
  }
}
