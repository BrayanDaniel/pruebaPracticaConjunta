import 'package:flutter/material.dart';

class PantallaResultado extends StatelessWidget {
  final String nombre;
  final String sexo;
  final String grupo;

  PantallaResultado({required this.nombre, required this.sexo, required this.grupo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Resultado',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 22,
              color: Colors.white,
            ),
          ),
        ),
        backgroundColor: Colors.green,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Ícono representando el resultado
            Icon(
              Icons.assignment_turned_in,
              size: 50,
              color: Colors.green,
            ),
            SizedBox(height: 20),
            // Nombre en verde
            Text(
              'Nombre: $nombre',
              style: TextStyle(
                fontSize: 18,
                color: Colors.green,
              ),
            ),
            // Sexo en verde
            Text(
              'Sexo: $sexo',
              style: TextStyle(
                fontSize: 18,
                color: Colors.green,
              ),
            ),
            SizedBox(height: 10),

            Text(
              'Grupo: $grupo',
              style: TextStyle(
                fontSize: 24,  // Tamaño más grande
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
            SizedBox(height: 30),
            // Botón con texto blanco, negrita y tamaño más grande
            SizedBox(
              width: 250,  // Hacemos el botón más estrecho
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                ),
                child: Text(
                  'Volver',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 18,  // Aumentamos el tamaño de la letra del botón
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
